// This is the base URL for the Node.js backend server.
export const API_BASE_URL = '';